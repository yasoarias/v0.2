<template>
    <div>
      <h2>Register</h2>
      <form @submit.prevent="register">
        <div>
          <label>Name:</label>
          <input v-model="name" type="text" required />
        </div>
        <div>
          <label>Email:</label>
          <input v-model="email" type="email" required />
        </div>
        <div>
          <label>Contact Number:</label>
          <input v-model="contactNumber" type="text" required />
        </div>
        <div>
          <label>Password:</label>
          <input v-model="password" type="password" required />
        </div>
        <button type="submit">Register</button>
      </form>
      <p v-if="errorMessage">{{ errorMessage }}</p>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        name: '',
        email: '',
        contactNumber: '',
        password: '',
        errorMessage: '',
      };
    },
    methods: {
      async register() {
        try {
          await axios.post('http://localhost:5000/api/auth/register', {
            name: this.name,
            email: this.email,
            contactNumber: this.contactNumber,
            password: this.password,
          });
  
          // Redirect to login page after successful registration
          this.$router.push('/login');
        } catch (error) {
          this.errorMessage = 'Registration failed. Please try again.';
        }
      },
    },
  };
  </script>
  