<template>
  <div class="home">
    <h1>Welcome to Razzrel Events</h1>
    <p>This is the home page.</p>
  </div>
</template>

<script>
export default {
  name: "HomePage",
};
</script>

<style scoped>
/* Add your styles here */
</style>
