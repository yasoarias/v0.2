<template>
  <div class="register">
    <h1>Register</h1>
    <form>
      <div>
        <label for="name">Name:</label>
        <input type="text" id="name" />
      </div>
      <div>
        <label for="email">Email:</label>
        <input type="email" id="email" />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" />
      </div>
      <button type="submit">Register</button>
    </form>
  </div>
</template>

<script>
export default {
  name: "RegisterForm",
};
</script>

<style scoped>
/* Add your styles here */
</style>
